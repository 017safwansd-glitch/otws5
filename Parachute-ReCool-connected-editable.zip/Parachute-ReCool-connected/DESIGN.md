# Connected visual strategy

Ten sustained scenes, 180 seconds, landscape 1920×1080. Retain the liked illustrated graphics, replace the 43-shot montage with progressive explanations. Every scene has a stable spatial arrangement. Narration drives only meaningful additions. No letter-by-letter animation, repeated pulses, bobbing bottles, particle wallpaper, giant ghost text, counters or per-sentence transitions.

## Identity
Ice #F4FAFC is the primary canvas; blue #073A68 for type and hero scenes; teal #087D91 for cooling; cyan #C4F3F3 for moisture; coral #EE6747 for heat. Anton display, IBM Plex Mono small labels. Large negative space, typography under 140px except hero title. No headers, footers, slides, cards or caption rail.

## Continuity
A single droplet is the visual protagonist: collar → skin/evaporation → returning discomfort → trigger → formulation. Skin geometry persists between humidity and mechanism. The same product position connects reveal, packs and closing. Bangladesh map connects launch to the business opportunity. Nine understated 0.7-second dissolves replace 42 aggressive wipes.

## Motion budget
One dominant action at a time, at most one supporting motion. Short purposeful movements followed by readable holds. Existing solutions build into one comparative landscape, not seven separate scenes. Formula builds a causal three-step diagram, not ingredient title cards. Numbers appear at their final values and remain for comparison. No infinite loops or bounce/elastic effects. The closing recalls the initial heat texture while cooling curves settle around the packs.
