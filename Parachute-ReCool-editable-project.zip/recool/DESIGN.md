## Style Prompt
Cinematic and realistic Bangladesh heat documentary moving into a fresh premium cooling product reveal. Light canvas, cool blue and icy cyan accents, photographic close-ups, generous typography, slow camera pushes and precise scientific diagrams. Preserve supplied pack pixels and mark proposed mechanism and business assumptions.
## Colors
- #F4FAFC: light canvas
- #073A68: main blue ink
- #087D91: deep cyan accent
- #C4F3F3: icy cyan surfaces
- #FFFFFF: white panels
## Typography
Inter for titles, body and numerical labels. Clean sans-serif, oversized headlines, compact upper-case section labels.
## Motion
0.5–0.8s layered entrance reveals; 0.45s scene crossfades; finite subtle photographic push-ins; staged particle movement in diagrams; no flashing effects.
## What NOT to Do
- Do not present the proposed mechanism as proven.
- Do not fabricate a consumer testimonial.
- Do not use generic neon gradients or dense slide layouts.
- Do not distort supplied product artwork.
- Do not show assumption-based financial figures as actual performance.
