# Parachute ReCool — three-minute pitch draft

180 seconds · 1920 × 1080 · 30 fps. Built with HyperFrames 0.8.145.

This draft follows the final revised script and uses three synthetic English narration voices. It contains supplied 60 ml and 150 ml concept pack artwork, a supplied logo, generated Bangladesh illustrative photographs, scientific diagrams, pricing and financial graphics, and captions. It does not contain recorded presenter footage or a genuine consumer interview.

## Review

Open the HyperFrames Studio preview. The rendered MP4 is `renders/Parachute-ReCool-draft.mp4`.

## Edit and render

Use Node.js 22+ and FFmpeg. From this directory:

```sh
npm run dev
npm run check
npm run render -- --output renders/Parachute-ReCool-draft.mp4 --fps 30 --quality high
```

On a Linux machine with system Chromium, set `HYPERFRAMES_BROWSER_PATH=/usr/bin/chromium` when rendering. The source uses a local GSAP file and local imagery/audio. The compiler embeds Inter.

`index.html` is the editable composition. `script.json` contains the narration sections; `captions.json` has timed text; `scenes.json` records scene timing. `DESIGN.md` defines the approved cinematic, light, blue/cyan direction. `assets/narration.wav` is the complete 180-second narration track.

## Genuine consumer interview

The 00:44–00:51 section is visibly labeled as a placeholder and narration is silent there. Replace it with the participant's actual recorded clip and words. Do not substitute an invented quote.

Place the video at `assets/consumer.mp4`. Replace the contents of `#s7 .stage` with the desired interview framing, and add a top-level muted video and separate audio element at 44 seconds, duration 7 seconds. Keep the root at 180 seconds. Use the actual recorded words for interview captions.

## Claims and visual provenance

- The proposed moisture-responsive mechanism is labeled as an innovation target subject to formulation testing.
- Pack prices and the launch are proposals.
- 1,189 crore taka retail potential, 17.22 crore taka Year Three net sales and 2.58 crore taka EBITDA are assumption-based estimates/projections supplied in the script.
- The World Bank temperature statistic was checked against its published report. Marico's About Us page displays 90% household reach, alongside prose using four out of five; see SOURCES.md for links and the measurement caveat. The trend graphic is schematic, not a time series dataset.
- Everyday-life photographs are generated illustrations, not recorded documentary evidence or testimonials.
- The supplied concept packs contain the artwork's original on-pack wording. That wording is not evidence of a tested product claim.
- Approximate caption splits within a sentence use its measured generated speech duration; sentence timings derive from the narration synthesis.

## Validation

All 27 scene hero frames were checked. Runtime, layout and contrast checks passed without errors. The CLI reports structural authoring suggestions for the single-file composition; scene layering during crossfades is intentional.
