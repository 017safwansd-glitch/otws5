## Style Prompt
Three-minute landscape pitch executed as a continuous motion-design film with the energy and typography of short-form reels. Objects explain the narration through movement, camera travel and transformations. Large condensed words are part of the scene, not captions in a box. Product cutouts occupy dimensional illustrated environments. No slide layouts, persistent chrome or photo panels.
## Colors
- #F4FAFC: ice-white main canvas
- #073A68: deep blue, cooling scenes and main ink
- #087D91: deep cyan, cooling accents
- #C4F3F3: ice cyan, waves and moisture
- #EE6747: heat coral, confined to problem and initial heat visuals
- #FFFFFF: white type on dark blue
## Typography
Anton for condensed kinetic display words. IBM Plex Mono for numbers, ingredient annotations and short supporting phrases. Extreme scale contrast, very little text, 140–300px display text, 30px+ explanatory labels. Both families are embedded locally.
## Motion
Primary 0.32s lateral camera/reveal transitions, with liquid iris and scale-through accents at conceptual changes. Choreograph each 3–7s shot individually. Animate diagrams continuously, not just entrances. Use acceleration, staged cause-and-effect, finite repetitions and matched positions between related shots. Count data into place. Animate bottle environments, preserve pack pixels.
## What NOT to Do
- No headers, footers, presenter labels, progress bars, subtitle rail, cards or interview placeholder.
- No repetitive title-left/graphic-right compositions.
- No fake testimonials or invented factual data.
- Do not imply the moisture-responsive formula has been proven.
- Do not show forecasts as achieved performance.
- Do not turn long sentences into text slides.
