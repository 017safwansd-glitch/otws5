# Parachute ReCool — three-minute pitch

React/TypeScript + Remotion assembly, with **three native Blender girl clips**, scientific/business graphics, and the supplied merged product video. Master: **1920×1080, 30 fps, 5,400 frames / exactly 180 seconds**.

The three uploaded PNGs are installed unchanged: `recool-logo.png` is the sole combined branding asset; `recool-60ml.png` and `recool-150ml.png` are the approved bottles. Missing presenter footage leaves plain white space: no boxes, silhouettes, labels, filenames, or position markers. Narration/music have not been supplied, so the current MP4 is a silent cut with editable script captions.

## Girl clips

| Clip | Master interval | Frames | Blender action |
|---|---|---|---|
| Opening | 00:00–00:20 | 600 | Home doorway → outdoors → discomfort → fan → outside again |
| Return outdoors | 01:01–01:07 | 180 | Leaves the fan and resumes her afternoon |
| Ending | 02:40–02:55.167 | 455 | Returns through the same doorway; amber droplet becomes cyan |

The 1,235 girl frames total 41.167 seconds. The science and business graphics remain in Remotion. The old React/SVG girl and doorway implementation has been removed. The Blender street set and articulated character are shared across the three shots. All three are independently rendered at normal speed, with no looping or stretching.

## Setup and preview

Requires Node 22+, npm, FFmpeg/ffprobe, and Chromium. Blender 4.3.2 is needed to rebuild the girl footage. These tools are available in the cloud environment.

```sh
cd /workspace/otws5
npm ci --cache /workspace/.npm-cache --no-audit --no-fund
npm run studio
```

Use the existing isolated checkout; no worktree is needed. Remotion packages are pinned together at 4.0.534. The config uses `/usr/bin/chromium`; override with `REMOTION_BROWSER_EXECUTABLE` on another machine. Installation preserves TLS and package integrity verification.

```sh
npm run check
npm run compositions
npm run review
npm run render
```

The render command writes `out/recool-pitch.mp4`. The preview compositions are ReCoolPitch, Scene1–Scene9, ScienceOnly, and SKUComparison. The onboarding interface does not expose a localhost preview link. Downloadable artifacts are delivered through the GitHub `recool-video-downloads` branch.

## Rebuild Blender footage

```sh
python blender/render_clips.py --workers 2
npm run assets
```

`blender/build_girl_scene.py` builds the native models, material palette, camera, fan, doorway, street, market, rickshaw, articulated character, and animation. It saves `girl-opening.blend`, `girl-return.blend`, and `girl-ending.blend`. The `.blend` sources are included so the character and camera can be edited in Blender. The render driver writes PNG frames to `/workspace/blender-cache`, then encodes exactly 600, 180, and 455 frames into `public/assets/girl-*.mp4`. Two software-rendering workers suit this machine's five CPUs. Blender's Workbench renderer and FXAA provide consistent stylized 3D without external assets or services.

The original girl timing is matched to the editable narration estimates. If those action timings change, update the builder's frame positions and rebuild the affected clips.

## Master timeline

| Scene | Frames (half-open) | Duration | Visual |
|---|---|---|---|
| 1 | [0,600) | 20 s | Blender opening + timeline |
| 2 | [600,1260) | 22 s | Humidity/climate graphics + plain white space |
| 3 | [1260,2010) | 25 s | Existing solutions + 6 s Blender return |
| 4 | [2010,2670) | 22 s | Sweat revelation + plain white space |
| 5 | [2670,3378) | 23.6 s | One merged source, 0–23.6 s |
| 6 | [3378,3903) | 17.5 s | Scientific animation |
| 7 | [3903,3960) | 1.9 s | Accurate product hero |
| 8 | [3960,4800) | 28 s | SKUs, map, forecasts + plain white space |
| 9 | [4800,5400) | 20 s | Blender ending, then final product card |

The original presenter allocation remains 72 seconds. Presenter video can be added later using presenter1/2/3.webm or matching MP4 files; absent footage renders nothing in that area. Regular MP4 is a rectangular video, while keyed alpha WebM supports transparency. Camera audio is muted to avoid doubling the master narration.

## Assets and audio

All media belongs in `public/assets/`. `npm run assets` refreshes the ignored manifest after media changes; restart Studio after adding files.

Installed: `recool-logo.png`, `recool-60ml.png`, `recool-150ml.png`, `recool-merged.mp4`, and `girl-opening.mp4`, `girl-return.mp4`, `girl-ending.mp4`.

Optional: presenter1/2/3.webm or MP4; full-length `narration.wav`; aligned `captions.srt`; full-timeline `music.wav` and `ambience.wav`; short `notification.wav`, `spray.wav`, `activation.wav`, `reveal.wav`. No narration is synthesized. Speech cues remain editable until the recording is available. Imported SRT is parsed with `@remotion/captions` and takes precedence over script captions. The script-caption timing note is documented here, rather than printed in the video.

After installing narration and actual aligned captions, disable the estimated captions when rendering:

```sh
npx remotion render src/index.ts ReCoolPitch out/recool-final.mp4 \
  --codec=h264 --concurrency=3 --props='{"showEstimatedCaptions":false}'
```

## Editable data

- `src/data/product.ts`: 60 ml / ৳175 and 150 ml / ৳275.
- `src/data/financials.ts`: Dhaka/Chattogram, TAM ৳1,189 crore, Year 3 sales ৳17.22 crore, EBITDA ৳2.58 crore.
- `src/data/narration.ts`: complete narration reference.
- `src/data/narration-cues.ts`: 55 editable phrase cues; export with `node scripts/export-cues.mjs`.
- `src/data/timeline.ts`: scene boundaries and source trims.
- `src/data/assets.ts`: audio levels, presenter side, hero replacement.
- `src/styles/theme.ts`: palette.

The science sequence communicates retained cooling agents, returned moisture, agent release, and TRPM8 sensory signaling. No core-body-temperature or heatstroke claim is introduced. Business figures retain their estimate/forecast labels. The +4.5°C statistic refers to feels-like temperature change since 1980, credited to World Bank, 2025. The map is based on public-domain Natural Earth boundaries; local English/Bengali fonts include the taka symbol and their license files.

The merged MP4 remains one physical source, referenced at 0–23.6 s and 23.6–25.5 s with playbackRate 1. Source video lettering is not relied on for important information. The small baked-in watermark is covered with a native branding panel, and the final hero uses the approved bottle/combined logo.

See `docs/RECORDING.md` for recording handoff and `docs/VALIDATION.md` for the latest output checks. Setup/startup configuration is saved separately in environment settings; publication retains the prepared workspace.
