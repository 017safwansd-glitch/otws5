# Parachute ReCool — three-minute pitch

A new React/TypeScript + Remotion film, built from the supplied production brief. The master is **1920 × 1080, 30 fps, exactly 5,400 frames / 180 seconds**. It includes nine individually previewable scenes, an original 525-frame scientific animation, editable prices/forecasts, narration cues, SRT captions, and replaceable presenter/audio/brand assets.

## Current delivery status

The project renders without optional assets. The supplied merged MP4 is installed. **This is a review draft until original product/logo PNGs, presenter recordings, and narration are installed.** Presenter placeholders occupy the exact requested 72 seconds; actual presenter visibility requires recordings. The other 108 seconds are full-screen graphics/video. No narration or music is synthesized. The default review captions are estimated script timings, explicitly marked as such.

Use **one combined official branding file: `recool-logo.png`**. No separate Parachute logo or ReCool wordmark is expected or requested. Inline chat images were visible as references but were not exposed as downloadable files in this workspace. No official artwork has been reconstructed or invented.

## Develop and render

Requires Node 22 or newer, npm, FFmpeg/ffprobe, and Chromium (provided in this cloud environment). Remotion packages are pinned together at 4.0.534. Use the existing isolated checkout; no worktree is needed.

```sh
cd /workspace/otws5
npm ci --cache /workspace/.npm-cache --no-audit --no-fund
npm run studio
```

After adding/replacing media, restart Studio so the asset inventory refreshes. The Studio port is 3000. The cloud onboarding UI does not expose a localhost preview link.

```sh
npm run check                  # TypeScript, real data/config checks, source metadata
npm run compositions           # Master, Scene1–Scene9, ScienceOnly, SKUComparison
node scripts/render-review.mjs # Render scene starts and representative visual QA frames
npm run render                 # out/recool-pitch.mp4, full 1080p H.264 render
npm run still                  # out/preview.png
```

The config uses `/usr/bin/chromium` when installed. Override with `REMOTION_BROWSER_EXECUTABLE=/absolute/path/to/chrome` on another machine. If neither exists, use Remotion's normal verified browser installation. No TLS, checksum, or browser-origin verification is disabled. The review script currently uses the cloud machine's `/usr/bin/chromium`.

Render a final cut with estimated captions disabled after installing the recorded narration and actual aligned SRT:

```sh
npx remotion render src/index.ts ReCoolPitch out/recool-final.mp4 \
  --codec=h264 --concurrency=3 --props='{"showEstimatedCaptions":false}'
```

## Install the media

Copy original files to `public/assets/`, keeping these names. Do not resize or stretch product images. They are displayed with `objectFit: contain`. Optional images have labeled fallback slots; an asset inventory prevents missing-file requests from crashing the render.

| Filename | Purpose | Status at creation |
|---|---|---|
| `recool-merged.mp4` | One merged AI product source | Installed from `otw s5 rocky.mp4` |
| `recool-logo.png` | **Combined official Parachute ReCool logo** | Original downloadable file needed |
| `recool-60ml.png` | Approved 60 ml bottle | Original downloadable file needed |
| `recool-150ml.png` | Approved 150 ml bottle | Original downloadable file needed |
| `presenter1.webm` | 22 s presenter 1, begins at master 00:20 | Optional slot |
| `presenter2.webm` | 22 s presenter 2, begins at master 01:07 | Optional slot |
| `presenter3.webm` | 28 s presenter 3, begins at master 02:12 | Optional slot |
| `narration.wav` | Complete 180 s recorded narration | Optional, not generated |
| `captions.srt` | Subtitles aligned to the actual recording | Optional |
| `music.wav` | Complete score bed, mixed at low volume | Optional |
| `ambience.wav` | Full-timeline ambience bed | Optional |
| `notification.wav` | Short phone notification sound | Optional |
| `spray.wav` | Subtle short spray effect | Optional |
| `activation.wav` | Restrained short scientific-response sound | Optional |
| `reveal.wav` | Short product-revelation sound | Optional |

Presenter `.mp4` files with the same basename are accepted when `.webm` is absent. Clips begin at their scene's first frame, so pre-trim recordings to their assigned speaking sections. Presenter audio is muted: put the mixed master speech in `narration.wav`. Regular MP4 footage remains a rectangular video slot. Green-screen MP4 does **not** become transparent automatically. Key it in a suitable external compositing workflow and substitute alpha-channel WebM if transparency is wanted. `src/data/assets.ts` controls presenter side, audio levels, and hero-shot replacement.

## Timeline and the single merged video

| Scene | Master frames (half-open) | Duration | Visual |
|---|---|---|---|
| 1 | [0,600) | 20 s | Illustrated Dhaka afternoon |
| 2 | [600,1260) | 22 s | Presenter 1 + humidity/climate |
| 3 | [1260,2010) | 25 s | The consumer's interrupted plans |
| 4 | [2010,2670) | 22 s | Presenter 2 + sweat revelation |
| 5 | [2670,3378) | 23.6 s | Source MP4 0–23.6 s |
| 6 | [3378,3903) | 17.5 s | Original science graphics |
| 7 | [3903,3960) | 1.9 s | Source MP4 23.6–25.5 s / approved hero replacement |
| 8 | [3960,4800) | 28 s | Presenter 3 + SKUs, market, forecasts |
| 9 | [4800,5400) | 20 s | Return to the doorway / final end card |

The uploaded file has a 25.533333-second decoded video track, 766 encoded frames at 30 fps (container duration approximately 25.565 seconds). Only its first 25.5 seconds are used. `@remotion/media` `Video` uses `trimBefore={708}` to seek source **23.6 seconds in this 30 fps composition**, and `trimAfter={765}` for the final source segment. The first instance uses 0–708. Both have `playbackRate={1}`, are muted, and point to the same physical source. No looping, reverse playback, slow motion, physical splitting, or Clip 4 exists.

Inspection found AI-generated packaging lettering and a baked-in watermark. Scene 5 covers the small watermark with a native concept label and provides native scientific annotations. Moving package lettering is not claimed to be corrected. The final 57-frame hero source is still correctly sought, but its displayed visual is replaced with the approved PNG (or an explicitly labeled slot until supplied), because a flat text patch would not reliably fix its moving label. Disable `replaceAiHero` in `src/data/assets.ts` only if an approved source shot is available.

## Edit the film

- `src/data/product.ts`: pack names, sizes, prices; one price edit updates all uses.
- `src/data/financials.ts`: launch cities, TAM, Year 3 net sales/EBITDA, and climate trend.
- `src/data/timeline.ts`: fixed scene boundaries and video segments.
- `src/data/narration.ts`: complete supplied narration reference.
- `src/data/narration-cues.ts`: 55 estimated word/phrase cues. Each has ID, scene, phrase, start/end frame, animation ID, emphasis, and notes. Major actions read these cue positions. Align them to recorded speech while preserving scene boundaries.
- `src/data/assets.ts`: media settings and audio mix levels.
- `src/styles/theme.ts`: editorial palette.
- `scripts/prepare-assets.mjs`: indexes optional media and parses SRT with `@remotion/captions`. The generated JSON is ignored; rerun `npm run assets` after media changes.

Full-screen graphics and presenter layouts have a lower caption area. Default review captions split long phrases into short timed groups. Imported SRT takes precedence, so provide concise one/two-line captions with accurate timestamps. No synthetic narration or invented speech recognition is used. A recording handoff is in `docs/RECORDING.md`, and `docs/narration-cues.csv` provides the estimated phrase timings for review. The full master narration must carry voiceovers during the full-screen sections.

Science is conceptual: a thin retained residue, returned moisture, possible cooling-agent release, and simplified TRPM8 sensory signaling. Menthol/TRPM8 is established science; the specific ReCool formulation's retention, moisture response, and useful repeated cooling are hypotheses pending validation. No two-hour efficacy, core-temperature reduction, heatstroke prevention, invented survey, or completed laboratory validation is asserted.

All market and financial values are supplied business-plan assumptions/forecasts, not measured sales. The +4.5°C label refers to feels-like temperature change since 1980, credited as World Bank, 2025; it is not relabeled as ordinary air-temperature change. The project does not independently audit the market-model assumptions or demonstrate ReCool efficacy. Map boundaries use Natural Earth public-domain data; city markers are illustrative. Local DejaVu and Noto fonts include English, Bengali, and the taka symbol; licenses accompany the font files.

## Review before final delivery

1. Install the three original PNGs and presenter footage. Check alpha/rectangular framing.
2. Record and install narration; align cues and SRT to actual spoken phrases.
3. Install licensed audio beds/effects if desired; check intelligibility.
4. Run `npm run check`, inspect the scene previews, and render the full final MP4.
5. Review timing and scientific/financial qualifications with the presenters.

The full render and stills demonstrate project readiness. They do not replace a finished presenter/narration recording or validate the proposed formulation. Cloud configuration is saved separately for review; publication is performed in environment settings.

Validation evidence and remaining production assets are listed in `docs/VALIDATION.md`.
