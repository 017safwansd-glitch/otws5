# Recording handoff

The speech reference is in `src/data/narration.ts`. The 55-cue sheet is in `docs/narration-cues.csv`, exported with `node scripts/export-cues.mjs`. Align the cue frames to the actual recording while preserving the scene boundaries.

| Speaker | On-camera interval | Other narration |
|---|---|---|
| Presenter 1 | 00:20–00:42 | Scenes 1 and 3 |
| Presenter 2 | 01:07–01:29 | Scenes 5 and 6 |
| Presenter 3 | 02:12–02:40 | Scene 9 |

The video contains no visible presenter markers. Empty areas are plain white space. Optional camera recordings can be added later. Scene 7, 02:10.1–02:12, has no speech.

Mix the full narration into `public/assets/narration.wav`. Place aligned subtitles in `public/assets/captions.srt`. Use concise captions that fit below the diagrams and pricing. MP4 camera clips remain rectangular; alpha-channel WebM can be substituted after independent keying. Camera audio is muted.

Presenter 1 is conversational and observant. Presenter 2 moves from curiosity to a clear sensory-cooling explanation. Presenter 3 communicates the opportunity and forecasts, then returns to the consumer's afternoon. The closing science line is now: “When sweat returns, cooling is designed to return.”
