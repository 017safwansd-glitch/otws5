# Recording handoff

The complete editable speech reference is in `src/data/narration.ts`. The initial 55-cue recording sheet is in `docs/narration-cues.csv`; it is exported from `src/data/narration-cues.ts` with `node scripts/export-cues.mjs`.

Record three presenters against the fixed scene boundaries. They remain voiceovers when full-screen illustrations/product/science footage appears.

| Speaker | Visible on camera | Other narration |
|---|---|---|
| Presenter 1 | 00:20–00:42 | Scenes 1 and 3 |
| Presenter 2 | 01:07–01:29 | Scenes 5 and 6 |
| Presenter 3 | 02:12–02:40 | Scene 9 |

Scene 7 (02:10.1–02:12) has no narration. Keep that short bridge clear.

Use the supplied English wording as the initial script. Rehearse against the scene previews, including the deliberately quick science section; estimated cue positions must be aligned to the real speech before final delivery. Do not infer synchronization from draft captions. The master timeline remains fixed at 180 seconds.

Mix speech into one full-length `public/assets/narration.wav`. Optional camera clips begin at the start of each visible section: presenter1.webm (22 s), presenter2.webm (22 s), presenter3.webm (28 s). MP4 alternatives are supported, but ordinary green-screen footage remains rectangular until independently keyed. Camera-slot audio is muted to avoid doubled speech.

Supply `public/assets/captions.srt` from the aligned recording. Keep captions concise and within the lower caption area. The official single combined logo is `public/assets/recool-logo.png`. Product originals are `recool-60ml.png` and `recool-150ml.png`. No separate logos or AI-video clips are needed.

Performance: Presenter 1 is conversational, noticing an ordinary afternoon's interruptions. Presenter 2 moves from curiosity to controlled confidence, explicitly distinguishing the proposed formulation from established TRPM8 science. Presenter 3 is commercially clear and decisive; the ending returns to a warmer human tone. Avoid claims of measured ReCool efficacy or realized financial performance.
