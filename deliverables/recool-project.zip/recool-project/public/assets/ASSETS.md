Official branding: recool-logo.png (one combined Parachute ReCool logo).
Approved product artwork: recool-60ml.png and recool-150ml.png.
These three original RGBA files are installed unchanged from the user's GitHub uploads.

The one merged source MP4 and the three native Blender girl MP4s are installed.
Presenter footage is optional: missing files leave clean white space with no markers.
Narration, SRT subtitles, and music/effects slots are documented in ../../README.md.
