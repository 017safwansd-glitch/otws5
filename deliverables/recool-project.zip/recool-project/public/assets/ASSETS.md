Use recool-logo.png as the ONE combined official Parachute ReCool branding asset.

Missing original images: recool-logo.png, recool-60ml.png, recool-150ml.png.
No separate Parachute or ReCool logos are required.

The merged MP4 has been installed. Presenter, narration, caption, and sound slots are documented in ../../README.md.
