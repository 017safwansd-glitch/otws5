import React from 'react';
import {AbsoluteFill,Sequence} from 'remotion';
import {SCENES} from './data/timeline';
import {sceneComponents} from './components/Scenes';
import {Captions,AudioTracks} from './components/CaptionsAndAudio';
import {staticFile} from 'remotion';
export type PitchProps={showEstimatedCaptions:boolean};
export const FontStyles:React.FC=()=> <style>{`@font-face {font-family:Editorial;src:url('${staticFile('assets/fonts/EditorialSans.ttf')}') format('truetype');font-weight:400;} @font-face {font-family:Editorial;src:url('${staticFile('assets/fonts/EditorialSans-Bold.ttf')}') format('truetype');font-weight:700;} @font-face {font-family:Bengali;src:url('${staticFile('assets/fonts/NotoSansBengali-Regular.ttf')}') format('truetype');} * {box-sizing:border-box;} `}</style>;
export const MainComposition:React.FC<PitchProps>=({showEstimatedCaptions})=> <AbsoluteFill style={{fontFamily:'Editorial, Bengali, sans-serif',background:'#F7F6F1'}}><FontStyles/>{SCENES.map((s,i)=>{const Scene=sceneComponents[i];return <Sequence key={s.id} from={s.from} durationInFrames={s.duration} name={`${s.id} / ${s.title}`}><Scene/></Sequence>})}<AudioTracks/><Captions showEstimated={showEstimatedCaptions}/></AbsoluteFill>;
export const ScenePreview:React.FC<{sceneId:number;showEstimatedCaptions:boolean}>=({sceneId,showEstimatedCaptions})=>{
 const scene=SCENES.find(s=>s.id===sceneId)!;const Component=sceneComponents[sceneId-1];return <AbsoluteFill style={{fontFamily:'Editorial, Bengali, sans-serif'}}><FontStyles/><Component/><AudioTracks offset={scene.from} duration={scene.duration}/><Captions offset={scene.from} showEstimated={showEstimatedCaptions}/></AbsoluteFill>;
};
