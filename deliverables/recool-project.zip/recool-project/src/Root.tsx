import React from 'react';
import {Composition} from 'remotion';
import {MainComposition,ScenePreview,FontStyles} from './MainComposition';
import {SCENES,FPS,DURATION} from './data/timeline';
import {ReCoolSKUComparison} from './components/ReCoolProducts';
const SKUPreview:React.FC=()=> <div style={{width:1920,height:1080,background:'#F7F6F1',fontFamily:'Editorial, Bengali, sans-serif',display:'grid',placeItems:'center'}}><FontStyles/><ReCoolSKUComparison/></div>;
export const Root:React.FC=()=> <><Composition id="ReCoolPitch" component={MainComposition} width={1920} height={1080} fps={FPS} durationInFrames={DURATION} defaultProps={{showEstimatedCaptions:true}}/>{SCENES.map(s=><Composition key={s.id} id={`Scene${s.id}`} component={ScenePreview} width={1920} height={1080} fps={FPS} durationInFrames={s.duration} defaultProps={{sceneId:s.id,showEstimatedCaptions:true}}/>)}<Composition id="ScienceOnly" component={ScenePreview} width={1920} height={1080} fps={FPS} durationInFrames={525} defaultProps={{sceneId:6,showEstimatedCaptions:true}}/><Composition id="SKUComparison" component={SKUPreview} width={1920} height={1080} fps={FPS} durationInFrames={240}/></>;
