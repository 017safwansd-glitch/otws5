export const theme = {ivory:'#F7F6F1',ink:'#18202B',amber:'#E99035',cyan:'#19B7CF',navy:'#111C32',purple:'#8062C9',muted:'#737B82',line:'#DCDDD6',skin:'#BE8E76'};
