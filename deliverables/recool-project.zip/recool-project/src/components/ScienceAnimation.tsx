import React from 'react';
import {useCurrentFrame} from 'remotion';
import {theme as t} from '../styles/theme';
import {cueFrame} from '../data/narration-cues';
import {ramp} from './motion';
import {RecurringSweatDroplet} from './RecurringSweatDroplet';
import {Folio,Kicker,Title} from './Editorial';
export const ConceptualSkinLayer:React.FC=()=> <g><path d="M70 370 Q470 347 900 371 T1580 370 V565 H70Z" fill={t.skin}/><path d="M70 370 Q470 347 900 371 T1580 370" stroke="#E1B299" strokeWidth="5" fill="none"/><path d="M210 356 Q470 340 740 355 T1150 355" stroke={t.purple} strokeWidth="7" fill="none" strokeLinecap="round" opacity=".85"/><text x="104" y="536" fill="#3D302E" fontSize="24" letterSpacing="2">CONCEPTUAL SKIN CROSS-SECTION</text><path d="M1180 286 L1270 344" stroke="#ACB4C3" strokeWidth="2"/><text x="1150" y="262" fill="#CAD6E6" fontSize="24">Thin formulation residue</text></g>;
export const CoolingAgentParticles:React.FC<{frame:number;release:number}>=({frame,release})=><g>{Array.from({length:14},(_,i)=>{const x=265+i*60;const mobile=i%3===0;const x2=x+(mobile?Math.sin(i+frame/80)*25*release:0);const y=349+(i%2)*5-(mobile?release*65:0);return <circle key={i} cx={x2} cy={y} r={mobile?8:6} fill={t.cyan} opacity={mobile?1:.55}/>})}</g>;
export const MoistureInteraction:React.FC<{wet:number}>=({wet})=><ellipse cx="570" cy="355" rx={190*wet} ry={14*wet} fill={t.cyan} opacity=".23"/>;
export const CoolingAgentRelease:React.FC<{release:number}>=({release})=><g opacity={release}><path d="M820 320 Q1010 245 1160 374" stroke={t.cyan} strokeWidth="2" fill="none" strokeDasharray="5 9"/><text x="737" y="214" fill={t.cyan} fontSize="23">Some retained cooling agents may become mobile</text></g>;
export const TRPM8Diagram:React.FC<{frame:number;progress:number}>=({frame,progress})=>{
 const travel=ramp(frame,cueFrame(6,'sensation'),60);return <g opacity={progress}><path d="M1120 430 Q1160 400 1180 417 L1245 464 Q1285 495 1330 476 L1480 442" stroke="#7E5855" strokeWidth="14" fill="none" strokeLinecap="round"/><path d="M1120 430 Q1160 400 1180 417 L1245 464 Q1285 495 1330 476 L1480 442" stroke={t.cyan} strokeWidth="7" fill="none" strokeLinecap="round" pathLength="1" strokeDasharray={`${travel} 1`}/><rect x="1093" y="402" width="46" height="36" rx="10" fill={t.navy} stroke={t.cyan} strokeWidth="4"/><circle cx="1115" cy={392-30*(1-progress)} r="8" fill={t.cyan}/><path d="M1087 424 L983 490" stroke="#BDCADE" strokeWidth="2"/><text x="857" y="522" fill={t.ivory} fontSize="27">TRPM8</text><text x="856" y="553" fill="#A2B2C8" fontSize="20">Cold-sensitive receptor</text><text x="1293" y="547" fill={t.cyan} fontSize="22">Sensory pathway</text></g>;
};
export const ScienceAnimation:React.FC=()=>{
 const f=useCurrentFrame();const wet=ramp(f,cueFrame(6,'contact'),60);const release=ramp(f,cueFrame(6,'release'),95);const receptor=ramp(f,cueFrame(6,'trpm8'),30);const payoff=f>=cueFrame(6,'payoff');
 const heading=f<cueFrame(6,'contact')?'Perspiration returns.':f<cueFrame(6,'release')?'Moisture contacts the residue.':f<cueFrame(6,'menthol')?'Cooling-agent release.':f<cueFrame(6,'trpm8')?'Menthol becomes available.':'A cooling sensation.';
 const y=160+wet*172;
 return <><Folio number="06" name="The mechanism" dark/><div style={{position:'absolute',left:90,top:158}}><Kicker color={t.cyan}>MOISTURE → RELEASE → SENSORY RESPONSE</Kicker><div style={{marginTop:25}}><Title size={76} color={t.ivory}>{payoff?'Sweat returns. Cooling is designed to return.':heading}</Title></div></div>
 {!payoff?<svg viewBox="0 0 1650 590" style={{position:'absolute',left:130,top:330,width:1650,height:520}}><ConceptualSkinLayer/><g opacity={1-ramp(f,115,40)}><foreignObject x="535" y={y-110} width="70" height="100"><RecurringSweatDroplet size={62} cool={1}/></foreignObject></g><MoistureInteraction wet={wet}/><CoolingAgentParticles frame={f} release={release}/><CoolingAgentRelease release={release*(1-receptor*.65)}/><TRPM8Diagram frame={f} progress={receptor}/>{f>=cueFrame(6,'menthol')&&<text x="265" y="280" fill={t.cyan} fontSize="27">MENTHOL / COOLING AGENT</text>}</svg>:<div style={{position:'absolute',left:850,top:470}}><RecurringSweatDroplet size={190} cool={1}/></div>}
 </>;
};
