import React from 'react';
import {useCurrentFrame} from 'remotion';
import {theme as t} from '../styles/theme';
import {ramp} from './motion';
import {Kicker, SmallNote} from './Editorial';
export const HumidityExplainer:React.FC=()=>{
 const f=useCurrentFrame();return <div><Kicker color={t.amber}>HUMID AIR / LESS EFFICIENT EVAPORATION</Kicker><svg viewBox="0 0 1060 330" style={{width:'100%',marginTop:20}}><path d="M0 259 Q260 248 540 265 T1060 258 V325 H0Z" fill={t.skin}/>{[90,240,440,625,820,990].map((x,i)=>{const travel=((f*.38+i*19)%105);return <g key={x}><ellipse cx={x} cy={246} rx="23" ry="9" fill={t.cyan}/><circle cx={x+Math.sin(i+f/90)*12} cy={235-travel} r="6" fill={t.cyan} opacity={.6*(1-travel/140)}/></g>})}{Array.from({length:16},(_,i)=><circle key={i} cx={50+(i%8)*138} cy={45+Math.floor(i/8)*75} r="9" fill={t.amber} opacity=".2"/>)}<text x="760" y="308" fill={t.ivory} fontSize="23">SKIN SURFACE</text><text x="22" y="40" fill={t.muted} fontSize="22">Moisture in the surrounding air</text></svg><SmallNote>Perspiration cools through evaporation.<br/>Humidity makes that process less efficient.</SmallNote></div>;
};
