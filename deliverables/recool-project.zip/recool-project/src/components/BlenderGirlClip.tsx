import React from 'react';
import {staticFile} from 'remotion';
import {Video} from '@remotion/media';
import {assets} from '../data/assets';
export const BlenderGirlClip:React.FC<{clip:'opening'|'return'|'ending'}>=({clip})=>{
 const key={opening:'girlOpening',return:'girlReturn',ending:'girlEnding'}[clip] as 'girlOpening'|'girlReturn'|'girlEnding';
 const path=assets[key];
 return path?<Video src={staticFile(path)} muted playbackRate={1} objectFit="contain" style={{width:'100%',height:'100%'}}/>:null;
};
