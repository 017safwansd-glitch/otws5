import React from 'react';
import {useCurrentFrame,interpolate} from 'remotion';
import {theme as t} from '../styles/theme';
import {RecurringSweatDroplet} from './RecurringSweatDroplet';
import {ramp} from './motion';
export const ProtagonistIllustration:React.FC<{x?:number;step?:number;droplet?:boolean;cool?:number}>=({x=0,step=0,droplet=false,cool=0})=><g transform={`translate(${x} ${Math.sin(step)*3})`}>
 <path d="M18 150 L10 228 M60 150 L76 228" stroke={t.ink} strokeWidth="17" strokeLinecap="round"/>
 <path d="M6 228 H28 M70 228 H88" stroke={t.ink} strokeWidth="9" strokeLinecap="round"/>
 <path d="M16 66 Q42 51 68 68 L83 167 H0Z" fill={t.purple}/>
 <path d="M18 77 Q4 96 -11 120 M62 78 Q74 98 81 130" stroke="#A56F52" strokeWidth="13" fill="none" strokeLinecap="round"/>
 <path d="M36 42 V66" stroke="#A56F52" strokeWidth="15"/>
 <ellipse cx="41" cy="30" rx="24" ry="30" fill="#B98263"/>
 <path d="M17 36 Q2 -8 40 -10 Q75 -10 69 44 L58 35 Q48 9 25 10 L24 47Z" fill={t.ink}/>
 <circle cx="51" cy="27" r="2.5" fill={t.ink}/><path d="M50 40 L59 40" stroke={t.ink} strokeWidth="2"/>
 <path d="M72 126 L101 123 L110 162 L70 166Z" fill="#C6A574"/>
 {droplet&&<foreignObject x="82" y="15" width="48" height="70"><RecurringSweatDroplet size={38} cool={cool}/></foreignObject>}
 </g>;
export const DhakaDoorway:React.FC<{outsideAt:number;fanAt?:number;returnAt?:number;ending?:boolean;responseAt?:number}>=({outsideAt,fanAt=9999,returnAt=9999,ending=false,responseAt=9999})=>{
 const f=useCurrentFrame(); const outside=ramp(f,outsideAt,60);const fan=ramp(f,fanAt,25)*(1-ramp(f,returnAt,25));
 const response=ramp(f,responseAt,35);const x=310+outside*230-fan*90;
 return <svg viewBox="0 0 1120 550" style={{width:'100%',height:'100%'}}>
 <rect x="0" y="0" width="1120" height="550" fill="#ECECE5"/>
 <rect x="370" y="0" width="750" height="550" fill={fan>.5?'#D6EBE8':'#F3DCC0'}/>
 <circle cx="971" cy="79" r="54" fill={t.amber} opacity=".55"/>
 {[450,560,700,830,1010].map((a,i)=><g key={a} opacity=".35"><rect x={a} y={65+i*19} width={78+i*8} height={310-i*19} fill="#9B8B78"/>{[0,1,2,3].map(j=><path key={j} d={`M${a+12} ${105+i*19+j*54} h48`} stroke="#F7F6F1" strokeWidth="15"/>)}</g>)}
 <path d="M404 227 H1060" stroke={t.ink} strokeWidth="3" opacity=".25"/>
 <path d="M650 218 L662 227 L674 216 L686 227 L698 219" fill="none" stroke={t.purple} strokeWidth="10"/>
 <rect x="118" y="88" width="233" height="382" fill={t.ink}/><rect x="137" y="106" width="195" height="364" fill="#929C99"/>
 <path d="M141 112 L260 147 V470 H141Z" fill="#D5C9AC"/><circle cx="245" cy="303" r="6" fill={t.ink}/>
 <rect x="0" y="469" width="1120" height="81" fill="#D9D8CB"/>
 <path d="M360 470 H1070" stroke={t.ink} strokeWidth="2" opacity=".3"/>
 <path d="M710 258 L895 258 L870 293 L695 293Z" fill={t.ink}/><path d="M721 258 V465 M874 258 V465" stroke={t.ink} strokeWidth="7"/>
 <g transform={`translate(${x} 247)`}><ProtagonistIllustration step={f/12} droplet={outside>.5&&fan<.5} cool={response}/></g>
 <g opacity={fan} transform="translate(400 280)"><path d="M15 91 V177 H-14 H44" stroke={t.ink} strokeWidth="9" fill="none"/><circle cx="15" cy="44" r="52" fill="#C0DFDA" stroke={t.ink} strokeWidth="4"/><g transform={`rotate(${f*14} 15 44)`}>{[0,120,240].map(a=><path key={a} d="M15 44 Q65 0 45 50 Q40 69 15 44Z" fill={t.cyan} transform={`rotate(${a} 15 44)`}/>)}</g></g>
 <text x="52" y="45" fontSize="19" fill={t.muted} letterSpacing="3">{ending?'THE SAME DOOR. THE SAME WEATHER.':'HOME → OUTDOORS'}</text>
 {response>.01&&<g opacity={response}><path d="M603 271 Q700 225 754 305" stroke={t.cyan} strokeWidth="4" fill="none" strokeDasharray="8 8"/><text x="758" y="310" fontSize="19" fill={t.ink}>A proposed new response</text></g>}
 </svg>;
};
