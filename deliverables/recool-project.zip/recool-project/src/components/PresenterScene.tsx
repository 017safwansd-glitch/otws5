import React from 'react';
import {staticFile} from 'remotion';
import {Video} from '@remotion/media';
import {assets,presenterSettings} from '../data/assets';
export const PresenterScene:React.FC<React.PropsWithChildren<{presenter:1|2|3;dark?:boolean}>>=({presenter,children})=>{
 const file=assets[`presenter${presenter}` as 'presenter1'];
 const right=presenterSettings.side==='right';
 return <>
  {file&&<div style={{position:'absolute',[right?'right':'left']:84,top:150,width:600,height:710,overflow:'hidden'}}>
   <Video src={staticFile(file)} muted={presenterSettings.muted} objectFit="contain" style={{width:'100%',height:'100%'}}/>
  </div>}
  <div style={{position:'absolute',[right?'left':'right']:84,top:156,width:1070,height:690}}>{children}</div>
 </>;
};
