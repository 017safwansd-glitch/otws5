import React from 'react';
import {staticFile} from 'remotion';
import {Video} from '@remotion/media';
import {assets,presenterSettings} from '../data/assets';
import {theme as t} from '../styles/theme';
export const PresenterScene:React.FC<React.PropsWithChildren<{presenter:1|2|3;dark?:boolean}>>=({presenter,children,dark})=>{
 const file=assets[`presenter${presenter}` as 'presenter1']; const right=presenterSettings.side==='right';
 return <><div style={{position:'absolute',[right?'right':'left']:84,top:150,width:600,height:710,borderRadius:16,overflow:'hidden',background:dark?'#19263C':'#EBEDE7'}}>
 {file?<Video src={staticFile(file)} muted={presenterSettings.muted} objectFit="contain" style={{width:'100%',height:'100%'}}/>:<><svg viewBox="0 0 600 710" style={{width:'100%',height:'100%'}}><path d="M121 583 Q120 354 300 350 Q480 354 479 583" fill={dark?'#2F4159':'#CFD5CF'}/><ellipse cx="300" cy="270" rx="95" ry="111" fill={dark?'#2F4159':'#CFD5CF'}/><path d="M110 624 H490" stroke={dark?'#56687B':'#B5C0B8'} strokeWidth="2"/></svg><div style={{position:'absolute',left:0,right:0,bottom:45,textAlign:'center',color:dark?'#C4D4E0':t.muted}}><div style={{fontSize:26,fontWeight:700}}>Presenter {presenter}</div><div style={{fontSize:19,marginTop:12}}>presenter{presenter}.webm / .mp4</div><div style={{fontSize:17,marginTop:10}}>Replaceable footage slot</div></div></>}
 </div><div style={{position:'absolute',[right?'left':'right']:84,top:156,width:1070,height:690}}>{children}</div></>;
};
