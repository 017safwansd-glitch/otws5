import React from 'react';
import {theme as t} from '../styles/theme';
export const RecurringSweatDroplet:React.FC<{size?:number;cool?:number;style?:React.CSSProperties}>=({size=100,cool=0,style})=>{
 const mix=(a:number,b:number)=>Math.round(a+(b-a)*cool);
 const fill=`rgb(${mix(233,25)},${mix(144,183)},${mix(53,207)})`;
 return <svg viewBox="0 0 100 140" width={size} height={size*1.4} style={style}><path d="M50 5 C41 26 9 63 9 88 A41 41 0 0 0 91 88 C91 63 59 26 50 5Z" fill={fill}/><path d="M28 86 Q24 108 44 116" fill="none" stroke={t.ivory} strokeWidth="6" strokeLinecap="round" opacity=".45"/></svg>;
};
export const SweatDroplet=RecurringSweatDroplet;
