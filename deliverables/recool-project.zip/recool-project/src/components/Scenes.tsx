import React from 'react';
import {useCurrentFrame,Sequence} from 'remotion';
import {theme as t} from '../styles/theme';
import {cueFrame} from '../data/narration-cues';
import {climate} from '../data/financials';
import {Panel,Folio,Kicker,Title,Reveal,SmallNote} from './Editorial';
import {AfternoonTimeline} from './AfternoonTimeline';
import {BlenderGirlClip} from './BlenderGirlClip';
import {HumidityExplainer} from './HumidityExplainer';
import {PresenterScene} from './PresenterScene';
import {SmartphoneNotification,SolutionComparison} from './SolutionComparison';
import {RecurringSweatDroplet} from './RecurringSweatDroplet';
import {ReCoolBrandLockup,ReCoolSKUComparison,ReCoolProductImage,ReCoolEndCard} from './ReCoolProducts';
import {ScienceAnimation} from './ScienceAnimation';
import {MergedProductVideo} from './MergedProductVideo';
import {MarketOpportunity,FinancialOpportunity} from './BusinessGraphics';
import {ramp,enter} from './motion';
export const SceneOne:React.FC=()=>{
 const f=useCurrentFrame();const fan=f>=cueFrame(1,'fan')&&f<cueFrame(1,'return');
 const heading=f<cueFrame(1,'doorway')?'An ordinary afternoon.':fan?'A moment of comfort.':f<cueFrame(1,'return')?'Ten minutes outside.':'Then, outside again.';
 return <Panel><Folio number="01" name="The afternoon begins"/><div style={{position:'absolute',left:85,top:215,width:510}}><Reveal><Kicker color={t.amber}>DHAKA / THE EVERYDAY HEAT</Kicker></Reveal><div style={{marginTop:30}}><Title size={86}>{heading}</Title></div><Reveal at={cueFrame(1,'itinerary')} style={{marginTop:40}}><SmallNote>An errand to run.<br/>A market to visit.<br/>Friends to meet at four.</SmallNote></Reveal><div style={{marginTop:50,fontSize:25,color:fan?t.cyan:t.amber}}>The weather follows her.</div></div><div style={{position:'absolute',left:660,top:200,width:1176,height:578}}><BlenderGirlClip clip="opening"/></div><AfternoonTimeline progress={ramp(f,180,390)*.23} time={f<cueFrame(1,'shade')?'2:15 PM':'2:25 PM'} cool={fan} interrupted={f>=cueFrame(1,'shade')}/></Panel>;
};
export const SceneTwo:React.FC=()=>{
 const f=useCurrentFrame();const metric=f>=cueFrame(2,'climate')&&f<cueFrame(2,'ordinary');
 return <Panel><Folio number="02" name="The discomfort follows"/><PresenterScene presenter={1}>{metric?<div style={enter(f,cueFrame(2,'climate'))}><Kicker color={t.amber}>BANGLADESH / CHANGE SINCE {climate.baseline}</Kicker><div style={{fontSize:210,lineHeight:1.05,fontWeight:700,color:t.amber,letterSpacing:-12,marginTop:35}}>+{climate.change.toFixed(1)}°C</div><div style={{marginTop:24,fontSize:34,fontWeight:700,letterSpacing:2}}>{climate.label}</div><div style={{marginTop:50}}><SmallNote>{climate.source}<br/>Feels-like temperature trend since {climate.baseline}</SmallNote></div></div>:f>=cueFrame(2,'ordinary')?<><Kicker>AN ORDINARY AFTERNOON</Kicker><div style={{marginTop:45}}><Title size={76}>The heat returns.<br/>So does the discomfort.</Title></div><div style={{marginTop:40}}><RecurringSweatDroplet size={120}/></div></>:<><Kicker color={t.amber}>HEAT + HUMIDITY</Kicker><div style={{marginTop:24,marginBottom:45}}><Title size={65}>Cooling gets harder.</Title></div><Reveal at={cueFrame(2,'evaporation')}><HumidityExplainer/></Reveal></>}</PresenterScene><AfternoonTimeline progress={.28} time="2:30 PM" interrupted/></Panel>;
};
export const SceneThree:React.FC=()=>{
 const f=useCurrentFrame();const outdoors=f>=cueFrame(3,'outdoors');
 return <Panel><Folio number="03" name="Relief has its conditions"/>{outdoors?<><div style={{position:'absolute',left:85,top:190,width:520}}><Kicker color={t.amber}>BACK OUTDOORS</Kicker><div style={{marginTop:30}}><Title size={80}>The need keeps coming back.</Title></div><div style={{marginTop:40}}><SmallNote>Her plans are still ahead.</SmallNote></div></div><div style={{position:'absolute',left:660,top:210,width:1176,height:578}}><Sequence from={cueFrame(3,'outdoors')} durationInFrames={180} layout="none"><BlenderGirlClip clip="return"/></Sequence></div></>:<><Reveal at={cueFrame(3,'notification')} style={{position:'absolute',left:85,top:155}}><SmartphoneNotification/></Reveal><div style={{position:'absolute',left:85,top:355}}><Kicker>ONE AFTERNOON. DIFFERENT USAGE CONDITIONS.</Kicker></div><div style={{position:'absolute',left:280,top:430,width:1370}}><SolutionComparison/></div></>}
 <AfternoonTimeline time={outdoors?'3:10 PM':'2:50 PM'} progress={outdoors?.61:.45} interrupted/></Panel>;
};
export const RevelationAnimation:React.FC=()=>{
 const f=useCurrentFrame();const cool=ramp(f,cueFrame(4,'question'),cueFrame(4,'cyan')-cueFrame(4,'question'));const branding=f>=cueFrame(4,'brand');
 return <div>{branding?<div style={enter(f,cueFrame(4,'brand'))}><Kicker color={t.cyan}>INTRODUCING PARACHUTE RECOOL</Kicker><div style={{marginTop:80}}><ReCoolBrandLockup width={720}/></div><div style={{fontSize:39,marginTop:60}}>Cooling designed around the return of sweat.</div></div>:<><Kicker color={cool>.5?t.cyan:t.amber}>{f<cueFrame(4,'sweat')?'WHAT KEEPS COMING BACK?':'WHAT IF MOISTURE BECAME THE TRIGGER?'}</Kicker><div style={{display:'flex',alignItems:'center',gap:90,marginTop:65}}><div style={{opacity:ramp(f,cueFrame(4,'heat'),15)}}><RecurringSweatDroplet size={180} cool={cool}/></div><div style={{fontSize:35,lineHeight:1.4,flex:1}}>{f<cueFrame(4,'sweat')?<><div style={{opacity:ramp(f,cueFrame(4,'heat'),12),color:t.amber}}>The heat.</div><div style={{opacity:ramp(f,cueFrame(4,'discomfort'),12),marginTop:18}}>The interruption.</div><div style={{opacity:ramp(f,cueFrame(4,'sweat'),12),marginTop:18}}>The sweat.</div></>:<div style={{opacity:ramp(f,cueFrame(4,'cyan'),22)}}><b>Sweat returns</b><div style={{color:t.cyan,margin:'12px 0'}}>↓</div><div>Cooling-agent release</div><div style={{color:t.cyan,margin:'12px 0'}}>↓</div><b style={{color:t.cyan}}>Cooling sensation returns</b></div>}</div></div></>}</div>;
};
export const SceneFour:React.FC=()=> <Panel><Folio number="04" name="A different question"/><PresenterScene presenter={2}><RevelationAnimation/></PresenterScene></Panel>;
export const SceneFive:React.FC=()=> <MergedProductVideo/>;
export const SceneSix:React.FC=()=> <Panel dark><ScienceAnimation/></Panel>;
export const SceneSeven:React.FC=()=> <MergedProductVideo hero/>;
export const SceneEight:React.FC=()=>{
 const f=useCurrentFrame();return <Panel><Folio number="08" name="The commercial case"/><PresenterScene presenter={3}>{f<cueFrame(8,'cities')?<><Kicker color={t.cyan}>TWO PROPOSED PACKS / TWO EVERYDAY OCCASIONS</Kicker><div style={{marginTop:35}}><ReCoolSKUComparison/></div></>:f<cueFrame(8,'route')?<MarketOpportunity/>:<FinancialOpportunity/>}</PresenterScene><div style={{position:'absolute',left:84,bottom:155,fontSize:19,color:t.muted}}>Pricing and launch strategy</div></Panel>;
};
export const SceneNine:React.FC=()=>{
 const f=useCurrentFrame();const end=f>=cueFrame(9,'brand');return <Panel dark={end}>{end?<ReCoolEndCard/>:<><Folio number="09" name="The afternoon continues"/><div style={{position:'absolute',left:85,top:190,width:510}}><Kicker color={t.amber}>THE WEATHER HAS NOT CHANGED</Kicker><div style={{marginTop:30}}><Title size={78}>{f<cueFrame(9,'product')?'Four o’clock. Outside again.':'A new possibility.'}</Title></div>{f>=cueFrame(9,'product')?<div style={{marginTop:30,display:'flex',alignItems:'center',gap:25}}><div style={{width:225,flexShrink:0}}><ReCoolProductImage id="goPack" height={200}/></div><div style={{fontSize:25,lineHeight:1.5}}>Cooling designed<br/>to respond as<br/>sweat returns.</div></div>:<div style={{marginTop:40}}><SmallNote>The same door.<br/>The same plans.<br/>Another chance to continue.</SmallNote></div>}</div><div style={{position:'absolute',left:660,top:200,width:1176,height:578}}><BlenderGirlClip clip="ending"/></div><AfternoonTimeline progress={.75+ramp(f,cueFrame(9,'plans'),230)*.25} time="4:00 PM" cool={f>=cueFrame(9,'response')}/></>}</Panel>;
};
export const sceneComponents=[SceneOne,SceneTwo,SceneThree,SceneFour,SceneFive,SceneSix,SceneSeven,SceneEight,SceneNine];
