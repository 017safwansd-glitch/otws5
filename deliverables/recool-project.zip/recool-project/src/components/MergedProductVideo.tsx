import React from 'react';
import {AbsoluteFill,staticFile,useCurrentFrame} from 'remotion';
import {Video} from '@remotion/media';
import {assets,replaceAiHero} from '../data/assets';
import {cueFrame} from '../data/narration-cues';
import {theme as t} from '../styles/theme';
import {ReCoolProductHero,AssetSlot,ReCoolBrandLockup} from './ReCoolProducts';
import {Kicker} from './Editorial';
export const MergedProductVideo:React.FC<{hero?:boolean}>=({hero=false})=>{
 const f=useCurrentFrame();const trimBefore=hero?708:0;const label=f<150?'PARACHUTE RECOOL / COOLING MIST':f<cueFrame(5,'agents')?'ETHANOL / DRYING CONTRIBUTION':f<450?'MENTHOL + MENTHYL LACTATE':'RETENTION SYSTEM';
 return <AbsoluteFill style={{background:t.navy}}>{assets.merged?<Video src={staticFile(assets.merged)} trimBefore={trimBefore} trimAfter={hero?765:708} playbackRate={1} muted objectFit="cover" style={{width:'100%',height:'100%',opacity:hero&&replaceAiHero?0:1}}/>:<AssetSlot file="recool-merged.mp4" label="Merged product footage" dark style={{margin:'auto',width:700,height:350}}/>}
 {hero&&replaceAiHero?<AbsoluteFill><ReCoolProductHero/></AbsoluteFill>:<><div style={{position:'absolute',left:0,right:0,top:0,height:230,background:'linear-gradient(#111C32D9,#111C3200)'}}/><div style={{position:'absolute',left:84,top:67}}><Kicker color={t.cyan}>{label}</Kicker>{f>=450&&<div style={{marginTop:18,fontSize:27,color:t.ivory}}>Maltitol + selected surfactants / thin residue</div>}</div><div style={{position:'absolute',right:0,bottom:0,width:390,height:270,background:t.navy,padding:'30px 35px',boxSizing:'border-box',color:'#CBD7E7',fontSize:20,lineHeight:1.4}}><ReCoolBrandLockup width={320} dark/><div style={{fontSize:16,marginTop:22}}>Cooling designed for your afternoon</div></div></>}
 </AbsoluteFill>;
};
