import React, {useState} from 'react';
import {Img,staticFile,useCurrentFrame} from 'remotion';
import {theme as t} from '../styles/theme';
import {assets} from '../data/assets';
import {products, brand} from '../data/product';
import {cueFrame} from '../data/narration-cues';
import {enter, ramp,settle} from './motion';
import {Kicker, SmallNote} from './Editorial';
export const AssetSlot:React.FC<{file:string;label:string;dark?:boolean;style?:React.CSSProperties}>=({file,label,dark,style})=><div style={{border:`1px dashed ${dark?'#63768B':'#B4BAB6'}`,borderRadius:12,background:dark?'#FFFFFF05':'#FFFFFF55',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:16,padding:28,color:dark?'#C4D4E0':t.muted,...style}}><div style={{width:42,height:42,border:`2px solid ${dark?'#63768B':'#B4BAB6'}`,borderRadius:8,display:'grid',placeItems:'center',fontSize:25}}>+</div><div style={{fontSize:20,textAlign:'center'}}>{label}</div><div style={{fontSize:17,letterSpacing:1,textAlign:'center'}}>{file}</div></div>;
export const ReCoolProductImage:React.FC<{id:'goPack'|'homePack';height?:number;dark?:boolean}>=({id,height=360,dark})=>{
 const [failed,setFailed]=useState(false);const p=products.find(p=>p.id===id)!;const path=assets[id];
 return path&&!failed?<Img src={staticFile(path)} onError={()=>setFailed(true)} style={{height,width:'100%',objectFit:'contain'}}/>:<AssetSlot file={p.file} label={`${p.size} ml / Approved product image`} dark={dark} style={{height,width:220,margin:'0 auto',boxSizing:'border-box'}}/>;
};
export const ReCoolBrandLockup:React.FC<{width?:number;dark?:boolean}>=({width=520,dark})=>{
 const [failed,setFailed]=useState(false);
 return assets.logo&&!failed?<Img src={staticFile(assets.logo)} onError={()=>setFailed(true)} style={{width,height:width/3,objectFit:'contain'}}/>:<AssetSlot file={brand.logo} label="Official combined branding asset" dark={dark} style={{width,height:140,boxSizing:'border-box'}}/>;
};
export const ReCoolSKUCard:React.FC<{index:number;sceneId?:number}>=({index,sceneId=8})=>{
 const f=useCurrentFrame();const p=products[index];const priceAt=cueFrame(sceneId,p.id);
 return <div style={{width:460,textAlign:'center',...enter(f,index*14)}}><Kicker color={t.ink}>{p.name}</Kicker><div style={{margin:'25px 0 24px',transform:`translateX(${(1-settle(f,index*14))*(index===0?-45:45)}px)`}}><ReCoolProductImage id={p.id} height={300}/></div><div style={{fontSize:25,marginBottom:10}}>{p.size} ml</div><div style={{fontSize:68,fontWeight:700,letterSpacing:-2,opacity:ramp(f,priceAt,18)}}>৳{p.price}</div><SmallNote>{p.description}</SmallNote></div>;
};
export const ReCoolSKUComparison:React.FC=()=> <div style={{display:'flex',gap:24}}><ReCoolSKUCard index={0}/><ReCoolSKUCard index={1}/></div>;
export const ReCoolProductHero:React.FC<{dark?:boolean}>=({dark=true})=><div style={{display:'flex',alignItems:'center',justifyContent:'center',gap:110,height:'100%'}}><div style={{width:380,flexShrink:0}}><ReCoolProductImage id="homePack" height={600} dark={dark}/></div><div><ReCoolBrandLockup width={600} dark={dark}/><div style={{fontSize:40,color:dark?t.ivory:t.ink,marginTop:45}}>A new cooling occasion.</div></div></div>;
export const ReCoolEndCard:React.FC=()=> <div style={{height:'100%',display:'flex',alignItems:'center',justifyContent:'center',gap:100}}><div style={{width:340}}><ReCoolProductImage id="homePack" height={600} dark/></div><div style={{width:1060}}><Kicker color={t.cyan}>THE AFTERNOON CONTINUES</Kicker><div style={{marginTop:30}}><ReCoolBrandLockup width={650} dark/></div><div style={{fontSize:62,fontWeight:700,lineHeight:1.15,marginTop:35,color:t.ivory}}>{brand.promise}</div><div style={{fontSize:36,marginTop:28,color:t.cyan}}>{brand.tagline}</div></div></div>;
