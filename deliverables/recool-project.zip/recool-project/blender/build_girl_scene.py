"""Native Blender 4.3 scene builder for the three ReCool girl clips.

Usage: blender -b --factory-startup --python blender/build_girl_scene.py -- --clip opening --sample 320
Each .blend includes the set, a reusable articulated character, and baked frame animation.
"""
import bpy, math, argparse, sys, os
from mathutils import Vector
from pathlib import Path
args=argparse.ArgumentParser()
args.add_argument('--clip',choices=['opening','return','ending'],default='opening')
args.add_argument('--sample',type=int,default=0)
args.add_argument('--render',action='store_true')
opt=args.parse_args(sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else [])
ROOT=Path(__file__).resolve().parents[1];CACHE=Path(os.environ.get('RECOOL_BLENDER_CACHE',str(ROOT.parent/'blender-cache')))/opt.clip;CACHE.mkdir(parents=True,exist_ok=True)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
for data in list(bpy.data.materials): bpy.data.materials.remove(data)
scene=bpy.context.scene
scene.render.engine='BLENDER_WORKBENCH'
scene.render.resolution_x=1280;scene.render.resolution_y=630;scene.render.resolution_percentage=100
scene.render.fps=30;scene.frame_start=1;scene.frame_end={'opening':600,'return':180,'ending':455}[opt.clip]
scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGB';scene.render.image_settings.compression=5
scene.render.threads_mode='FIXED';scene.render.threads=4
scene.display.render_aa='FXAA'
sh=scene.display.shading;sh.light='STUDIO';sh.studiolight_rotate_z=.4;sh.color_type='MATERIAL';sh.show_shadows=True;sh.show_cavity=True;sh.cavity_type='SCREEN';sh.curvature_ridge_factor=1.25;sh.curvature_valley_factor=1.0;sh.show_specular_highlight=False;sh.background_type='WORLD'
scene.world.color=(.92,.91,.88)
scene.view_settings.view_transform='Standard';scene.view_settings.look='Medium High Contrast';scene.view_settings.exposure=0;scene.view_settings.gamma=1

def material(name,color):
 m=bpy.data.materials.new(name)
 c=tuple(int(color[i:i+2],16)/255 for i in (1,3,5));m.diffuse_color=(*c,1);return m
M={k:material(k,v) for k,v in {'ivory':'#F7F6F1','cream':'#EADBBF','wall':'#C6D2C8','interior':'#89A5A0','navy':'#273344','dark':'#17202A','road':'#737E7A','stone':'#CECCBD','skin':'#B98160','skinlight':'#C89171','hair':'#252723','purple':'#8062C9','scarf':'#69B9B9','amber':'#E99035','cyan':'#19B7CF','white':'#FFFFFF','pink':'#D8B3A7','window':'#728784','green':'#51836C','leaf':'#7A9D6D','bag':'#BC9260','metal':'#ADC5BE','lip':'#835141','tire':'#253231','orange':'#DE9D45','red':'#B75553'}.items()}

def finish(o,name,mat,parent=None):
 o.name=name;o.data.materials.append(M[mat] if isinstance(mat,str) else mat)
 if parent:o.parent=parent
 return o

def empty(name,loc=(0,0,0),parent=None):
 o=bpy.data.objects.new(name,None);scene.collection.objects.link(o);o.location=loc
 if parent:o.parent=parent
 return o

def cube(name,loc,scale,mat,bevel=.0,parent=None):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.scale=scale
 bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 if bevel:
  mod=o.modifiers.new('Soft edges','BEVEL');mod.width=bevel;mod.segments=3
  o.modifiers.new('Weighted normals','WEIGHTED_NORMAL')
 return finish(o,name,mat,parent)

def sphere(name,loc,scale,mat,parent=None):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=20,ring_count=12,radius=1,location=loc);o=bpy.context.object;o.scale=scale
 for f in o.data.polygons:f.use_smooth=True
 return finish(o,name,mat,parent)

def cyl(name,a,b,radius,mat,parent=None):
 a=Vector(a);b=Vector(b);mid=(a+b)/2
 bpy.ops.mesh.primitive_cylinder_add(vertices=20,radius=radius,depth=(b-a).length,location=mid);o=bpy.context.object;o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler()
 for f in o.data.polygons:f.use_smooth=True
 return finish(o,name,mat,parent)

def capsule(name,a,b,radius,mat,parent=None):
 o=cyl(name,a,b,radius,mat,parent);sphere(name+' rounded joint',a,(radius,)*3,mat,parent);sphere(name+' rounded end',b,(radius,)*3,mat,parent);return o

def curve(name,points,mat,width=.018,parent=None):
 d=bpy.data.curves.new(name,'CURVE');d.dimensions='3D';d.bevel_depth=width;d.bevel_resolution=3
 spl=d.splines.new('BEZIER');spl.bezier_points.add(len(points)-1)
 for p,co in zip(spl.bezier_points,points):p.co=co;p.handle_left_type='AUTO';p.handle_right_type='AUTO'
 o=bpy.data.objects.new(name,d);scene.collection.objects.link(o);return finish(o,name,mat,parent)

def text(name,body,loc,size,mat):
 d=bpy.data.curves.new(name,'FONT');d.body=body;d.size=size;d.extrude=.003;d.align_x='CENTER'
 o=bpy.data.objects.new(name,d);scene.collection.objects.link(o);o.location=loc;o.rotation_euler=(math.pi/2,0,0);return finish(o,name,mat)

# A small reusable Dhaka set: the same home threshold, footpath, market, and street.
cube('Ground',(0,2,-.2),(18,14,.35),'ivory')
cube('Sidewalk',(0,-.8,-.06),(16,3.7,.12),'stone',.035)
cube('Quiet street',(0,-3.2,-.08),(18,2.6,.12),'road',.03)
for x in range(-8,9):cube('Curb segment',(x,-2.52,.015),(.9,.18,.2),'cream',.02)
for x in [-6,-2,2,6]:cube('Street dash',(x,-3.25,-.006),(1.9,.045,.012),'cream')
# Home facade built around an actual door opening.
cube('Home left wall',(-5.9,1.8,2.05),(1.8,3.0,4.1),'cream',.035)
cube('Home right wall',(-2.25,1.8,2.05),(1.85,3,4.1),'cream',.035)
cube('Lintel above doorway',(-4.1,1.8,3.6),(1.85,3,1),'cream',.035)
cube('Interior back wall',(-4.1,3.18,1.7),(1.9,.12,3.4),'interior')
cube('Indoor floor',(-4.1,1.6,.02),(1.9,3,.09),'wall')
cube('Door frame left',(-5.03,.21,1.55),(.12,.15,3.15),'navy',.015)
cube('Door frame right',(-3.15,.21,1.55),(.12,.15,3.15),'navy',.015)
cube('Door frame top',(-4.1,.21,3.15),(2,.15,.14),'navy',.015)
door=empty('Door hinge',(-4.96,.18,.02))
cube('Door leaf',(.86,0,1.53),(1.75,.09,3.04),'wall',.025,door)
cube('Door inset',(.88,-.057,1.58),(1.4,.04,2.61),'cream',.03,door)
sphere('Brass door handle',(1.54,-.13,1.41),(.06,.04,.06),'bag',door)
cube('Threshold step',(-4.1,-.12,.06),(2.2,.54,.15),'ivory',.025)
cube('Home porch',(-4.16,-.48,3.56),(5.6,1.8,.2),'wall',.03)
for x in [-6.58,-1.72]:cyl('Porch post',(x,-1.27,0),(x,-1.27,3.56),.045,'navy')
# Teal louvered window.
cube('Home window recess',(-2.32,.19,2.18),(1.1,.05,1.12),'navy',.015)
for z in [1.75,1.91,2.07,2.23,2.39,2.55]:cube('Window louver',(-2.32,.12,z),(1.04,.05,.05),'interior',.01)
text('Home address','15',(-5.55,.08,2.1),.22,'navy')
# Potted plants ground the ordinary home setting.
for x in [-6.05,-1.65]:
 cyl('Terracotta pot',(x,-.15,0),(x,-.15,.36),.18,'pink')
 for i in range(5):sphere('Porch leaves',(x+.1*math.sin(i*2),-.15+.08*math.cos(i),.45+.07*i),(.16,.13,.24),'leaf')
# Pedestal fan, with genuinely rotating three-dimensional blades.
fanx=-2.8;fany=-.45
cyl('Fan pedestal',(fanx,fany,.05),(fanx,fany,1.15),.04,'metal');cube('Fan foot',(fanx,fany,.06),(.6,.42,.12),'navy',.06)
rotor=empty('Rotating fan rotor',(fanx,fany,1.45))
sphere('Fan motor',(0,.07,0),(.12,.14,.12),'navy',rotor)
for i in range(3):
 blade=sphere('Fan blade',(0,0,0),(.1,.035,.31),'cyan',rotor);a=i*2*math.pi/3;blade.location=(math.sin(a)*.19,-.035,math.cos(a)*.19);blade.rotation_euler[1]=a
for i in range(2):
 pts=[(fanx+math.sin(a)*(.39-i*.1),fany-.09,1.45+math.cos(a)*(.39-i*.1)) for a in [j*math.pi/32 for j in range(65)]]
 curve('Fan guard ring',pts,'metal',.012)
for a in [i*math.pi/4 for i in range(8)]:cyl('Fan guard spokes',(fanx,fany-.1,1.45),(fanx+math.sin(a)*.39,fany-.1,1.45+math.cos(a)*.39),.007,'metal')
# Distant Dhaka buildings with rooftop water storage and balcony rails.
for i,(x,w,h,mat) in enumerate([(0.6,2.1,4.4,'pink'),(3.2,2.5,5.3,'wall'),(6.4,2.35,4.8,'cream')]):
 cube('Neighbourhood building',(x,4.6,h/2),(w,2.6,h),mat,.04)
 for z in [1.1,2.2,3.3,4.4]:
  if z+.35<h:
   for dx in [-.57,.57]:cube('Shaded window',(x+dx,3.27,z),(.55,.035,.65),'window',.008)
   cube('Balcony ledge',(x,3.08,z-.45),(w*.86,.42,.1),'cream')
   for dx in [-.75,-.5,-.25,0,.25,.5,.75]:cyl('Balcony rail',(x+dx,2.95,z-.4),(x+dx,2.95,z+.12),.012,'navy')
   cyl('Balcony handrail',(x-.8,2.95,z+.12),(x+.8,2.95,z+.12),.014,'navy')
 cyl('Rooftop tank',(x,4.8,h),(x,4.8,h+.58),.34,'navy')
 cube('Roof cornice',(x,4.6,h),(w+.18,2.78,.15),'cream',.02)
# Market stand at the right of the same street.
for x in [3.25,5.95]:cyl('Market post',(x,.05,0),(x,.05,2.75),.045,'navy')
for i in range(8):
 strip=cube('Striped market awning',(3.45+i*.34,.5,2.7),(.345,1.65,.10),'cream' if i%2 else 'green',.008);strip.rotation_euler[0]=-.12
cube('Market counter',(4.6,.3,.71),(2.8,.9,.19),'bag',.025)
for x in [3.5,4.5,5.5]:
 cube('Produce crate',(x,.3,.89),(.75,.65,.22),'cream',.025)
 for i in range(8):sphere('Market fruit',(x+(i%3-1)*.16,.13+(i//3)*.13,1.08),(.095,)*3,'orange' if x==3.5 else 'green')
text('Market sign','BAZAR',(4.65,-.12,2.27),.22,'navy')
# A recognizable restrained rickshaw, parked beyond the protagonist's path.
rick=empty('Parked rickshaw',(6.1,-2.82,.02))
for x,y in [(-.48,0),(.48,0),(0,-1.12)]:
 bpy.ops.mesh.primitive_torus_add(major_radius=.33,minor_radius=.042,major_segments=24,minor_segments=8,location=(x,y,.34));o=bpy.context.object;o.rotation_euler=(0,math.pi/2,0);finish(o,'Rickshaw tire','tire',rick)
 cyl('Wheel axle',(x-.055,y,.34),(x+.055,y,.34),.025,'metal',rick)
cube('Rickshaw passenger seat',(0,.0,.82),(.94,.72,.18),'red',.04,rick)
cube('Rickshaw seat back',(0,.38,1.15),(.94,.10,.65),'green',.08,rick)
for x in [-.48,.48]:curve('Rickshaw canopy arch',[(x,-.25,.75),(x,.05,1.6),(x,.42,1.67)],'green',.055,rick)
cube('Rickshaw canopy',(0,.12,1.65),(1.09,.77,.15),'green',.09,rick)
cyl('Rickshaw frame',(0,-.9,.36),(0,-.17,.66),.045,'metal',rick)
cyl('Rickshaw handlebar',(-.35,-1.03,1.11),(.35,-1.03,1.11),.025,'navy',rick)
# Overhead wires and a roadside tree, without filling every part of the composition.
for x in [1.2,7.8]:cyl('Street utility pole',(x,2.7,0),(x,2.7,5.9),.055,'navy')
for z in [5.25,5.65]:curve('Overhead street wire',[(1.2,2.7,z),(4.1,2.7,z-.4),(7.8,2.7,z)],'navy',.008)
cyl('Tree trunk',(8,.3,0),(8,.3,2.5),.13,'bag')
for i in range(6):sphere('Tree canopy',(8+.6*math.sin(i),.3+.4*math.cos(i),2.8+.24*(i%3)),(.68,.5,.68),'leaf' if i%2 else 'green')

# Reusable, articulated young adult character in a salwar kameez.
girl=empty('Girl root',(-4.1,-.65,0))
head=empty('Head pose',(0,0,1.9),girl)
sphere('Neck',(0,0,1.8),(.09,.09,.18),'skin',girl)
bpy.ops.mesh.primitive_cone_add(vertices=32,radius1=.38,radius2=.26,depth=.9,location=(0,0,1.27));o=bpy.context.object;o.scale.y=.72
for f in o.data.polygons:f.use_smooth=True
finish(o,'Kameez tunic','purple',girl)
sphere('Shoulder line',(0,0,1.7),(.32,.22,.15),'purple',girl)
curve('Tunic piping',[(-.25,-.26,.88),(0,-.29,.86),(.25,-.26,.88)],'scarf',.013,girl)
curve('Scarf around collar',[(-.19,-.05,1.8),(-.1,-.25,1.73),(.16,-.2,1.7),(.24,-.08,1.79)],'scarf',.055,girl)
curve('Scarf drape',[(.16,-.2,1.73),(.21,-.26,1.48),(.11,-.28,1.13)],'scarf',.055,girl)
sphere('Hair volume',(0,.03,.24),(.24,.21,.29),'hair',head)
sphere('Face',(0,-.087,.20),(.205,.186,.245),'skinlight',head)
for side in [-1,1]:
 sphere('Ear',(side*.206,-.025,.19),(.047,.04,.07),'skin',head)
 sphere('Eye white',(side*.081,-.255,.25),(.047,.027,.033),'white',head)
 sphere('Iris',(side*.081+.005,-.278,.25),(.022,.014,.025),'dark',head)
 sphere('Eye glint',(side*.081+.011,-.290,.26),(.006,.004,.007),'white',head)
 curve('Eyebrow',[(side*.047,-.259,.302),(side*.082,-.269,.313),(side*.119,-.251,.304)],'hair',.008,head)
sphere('Nose',(.008,-.282,.19),(.035,.038,.045),'skin',head)
curve('Mouth',[(-.043,-.253,.111),(0,-.265,.102),(.048,-.248,.112)],'lip',.007,head)
# Hair part and a low braid visible in three-quarter views.
curve('Fringe',[(-.19,-.12,.34),(-.06,-.24,.423),(.12,-.20,.38)],'hair',.042,head)
for i in range(5):sphere('Braid',(0,.20,.10-i*.065),(.062,.058,.07),'hair',head)
hips=[];knees=[];shoulders=[];elbows=[]
for side in [-1,1]:
 hip=empty('Left hip' if side<0 else 'Right hip',(side*.14,0,.88),girl);hips.append(hip)
 capsule('Upper trouser leg',(0,0,0),(0,0,-.39),.075,'navy',hip)
 knee=empty('Knee',(0,0,-.39),hip);knees.append(knee)
 capsule('Lower trouser leg',(0,0,0),(0,0,-.38),.067,'navy',knee)
 sphere('Sandals',(0,-.085,-.4),(.087,.17,.05),'bag',knee)
 cube('Sandal strap',(0,-.04,-.351),(.155,.055,.025),'navy',.012,knee)
 shoulder=empty('Shoulder',(side*.29,0,1.69),girl);shoulders.append(shoulder)
 capsule('Kameez sleeve',(0,0,0),(0,0,-.29),.079,'purple',shoulder)
 elbow=empty('Elbow',(0,0,-.29),shoulder);elbows.append(elbow)
 capsule('Forearm',(0,0,0),(0,0,-.29),.052,'skin',elbow)
 sphere('Hand',(0,-.009,-.33),(.057,.045,.075),'skinlight',elbow)
# Small canvas shoulder bag, with a real strap rather than floating iconography.
curve('Shoulder bag strap',[(.27,-.02,1.73),(.4,-.06,1.46),(.43,-.07,1.11)],'bag',.02,girl)
cube('Canvas bag',(.43,-.03,.96),(.24,.16,.34),'bag',.05,girl)
# The narrative sweat droplet is a small three-dimensional object, never a Remotion girl illustration.
dropMat=material('Sweat motif','#E99035');vertices=[];faces=[]
for j,(z,r) in enumerate([(0,.035),(.025,.055),(.062,.055),(.10,.037),(.145,0)]):
 for i in range(16):a=i*math.pi/8;vertices.append((r*math.cos(a),r*math.sin(a),z))
for j in range(4):
 for i in range(16):faces.append((j*16+i,j*16+(i+1)%16,(j+1)*16+(i+1)%16,(j+1)*16+i))
mesh=bpy.data.meshes.new('Teardrop mesh');mesh.from_pydata(vertices,[],faces);mesh.update()
drop=bpy.data.objects.new('Sweat droplet',mesh);scene.collection.objects.link(drop);drop.parent=girl;drop.location=(.28,-.17,2.0);drop.data.materials.append(dropMat)
for p in mesh.polygons:p.use_smooth=True

# Camera establishes the same composition in all three clips.
bpy.ops.object.camera_add(location=(9,-19,10.1));camera=bpy.context.object
camera.rotation_euler=(Vector((.05,.9,1.85))-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.type='ORTHO';camera.data.ortho_scale=14.6;scene.camera=camera

def ease(f,a,b):
 t=max(0,min(1,(f-a)/(b-a)));return t*t*(3-2*t)
def mix(a,b,t):return a+(b-a)*t
# Frame positions deliberately match the centralized narration cues in the React master.
for frame in range(1,scene.frame_end+1):
 f=frame-1; moving=0;shade=0;cool=0
 if opt.clip=='opening':
  if f<220:x=-4.1
  elif f<305:x=mix(-4.1,.2,ease(f,240,305));moving=1
  elif f<420:x=mix(.2,-1.6,ease(f,335,417));moving=1 if 335<f<417 else 0
  elif f<510:x=-1.6
  else:x=mix(-1.6,1.8,ease(f,510,595));moving=1 if f<595 else 0
  shade=ease(f,300,322)*(1-ease(f,350,380))
  visible=(285<=f<420 or f>=550);opening=ease(f,198,243)
 elif opt.clip=='return':
  x=mix(-1.6,1.9,ease(f,50,172));moving=1 if 50<f<172 else 0
  shade=ease(f,0,20)*(1-ease(f,45,65));visible=f>80;opening=1
 else:
  x=mix(-4.1,2.7,ease(f,65,230));moving=1 if 65<f<230 else 0
  if f>=330:x=mix(2.7,3.9,ease(f,360,450));moving=1 if 360<f<450 else 0
  visible=f>=150;cool=ease(f,340,385);opening=ease(f,43,88)
 phase=f*math.pi/18
 y=mix(.65,-.85,ease(f,220,260)) if opt.clip=='opening' else mix(.65,-.85,ease(f,65,105)) if opt.clip=='ending' else -.85
 girl.location=(x,y,.015+abs(math.sin(phase))*.016*moving)
 girl.rotation_euler[2]=(1.35 if opt.clip!='opening' or f<305 or f>=510 else -1.35) if moving else .08
 head.rotation_euler=(.01,.055*shade,.12*shade)
 for i,side in enumerate([-1,1]):
  hips[i].rotation_euler[0]=math.sin(phase+(0 if i==0 else math.pi))*.34*moving
  knees[i].rotation_euler[0]=max(0,-math.sin(phase+(0 if i==0 else math.pi)))*.42*moving
  shoulders[i].rotation_euler=(math.sin(phase+(math.pi if i==0 else 0))*.23*moving,side*-.08,0)
  elbows[i].rotation_euler[0]=-.18
 shoulders[1].rotation_euler[0]=mix(shoulders[1].rotation_euler[0],-1.75,shade)
 elbows[1].rotation_euler[0]=mix(-.18,-1.25,shade)
 door.rotation_euler[2]=-.96*opening
 rotor.rotation_euler[1]=f*.72
 drop.scale=(1,1,1) if visible else (.0001,)*3
 drop.location.z=2.0-.02*math.sin(f/15)
 dropMat.diffuse_color=(mix(233/255,25/255,cool),mix(144/255,183/255,cool),mix(53/255,207/255,cool),1)
 for obj in [girl,head,*hips,*knees,*shoulders,*elbows,door,rotor]:
  obj.keyframe_insert(data_path='location',frame=frame);obj.keyframe_insert(data_path='rotation_euler',frame=frame)
 drop.keyframe_insert(data_path='scale',frame=frame);drop.keyframe_insert(data_path='location',frame=frame);dropMat.keyframe_insert(data_path='diffuse_color',frame=frame)
for action in bpy.data.actions:
 for fc in action.fcurves:
  for p in fc.keyframe_points:p.interpolation='LINEAR'
scene.render.filepath=str(CACHE/'frame-')
scene.frame_set(opt.sample or 1)
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'blender'/f'girl-{opt.clip}.blend'))
if opt.sample:
 scene.render.filepath=str(CACHE/'sample.png');bpy.ops.render.render(write_still=True)
if opt.render:
 scene.render.filepath=str(CACHE/'frame-');bpy.ops.render.render(animation=True)
print('Completed native Blender scene:',opt.clip,'frames:',scene.frame_end)
