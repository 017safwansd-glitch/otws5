#!/usr/bin/env python3
"""Render three native Blender animations, then encode exact-frame 30 fps MP4s.
The cache is outside the project archive. No generated video frames are looped.
"""
from pathlib import Path
import subprocess,os,concurrent.futures,argparse,time,json
ROOT=Path(__file__).resolve().parents[1];CACHE=Path(os.environ.get('RECOOL_BLENDER_CACHE',str(ROOT.parent/'blender-cache')))
p=argparse.ArgumentParser();p.add_argument('--workers',type=int,default=2);a=p.parse_args()
CLIPS=[('opening',600),('ending',455),('return',180)]
def render(spec):
 name,count=spec;folder=CACHE/name;folder.mkdir(parents=True,exist_ok=True)
 env=os.environ.copy();env.update({'MESA_SHADER_CACHE_DIR':str(CACHE/'shader-cache'),'XDG_CACHE_HOME':str(CACHE),'LP_NUM_THREADS':'2'})
 log=folder/'render.log'
 with log.open('w') as f:
  subprocess.run(['blender','-b','--factory-startup','--python-exit-code','1','--python','blender/build_girl_scene.py','--','--clip',name,'--render'],cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
 if f'Completed native Blender scene: {name}' not in log.read_text():raise RuntimeError(f'Blender did not complete {name}')
 frames=list(folder.glob('frame-*.png'))
 if len(frames)!=count:raise RuntimeError(f'{name}: got {len(frames)} frames; expected {count}')
 dest=ROOT/'public/assets'/f'girl-{name}.mp4'
 subprocess.run(['ffmpeg','-y','-v','error','-framerate','30','-start_number','1','-i',str(folder/'frame-%04d.png'),'-frames:v',str(count),'-c:v','libx264','-crf','17','-pix_fmt','yuv420p','-movflags','+faststart','-threads','2',str(dest)],check=True)
 probe=subprocess.check_output(['ffprobe','-v','error','-show_entries','stream=nb_frames,r_frame_rate,width,height:format=duration','-of','json',str(dest)],text=True)
 meta=json.loads(probe);v=meta['streams'][0]
 if int(v['nb_frames'])!=count or v['r_frame_rate']!='30/1':raise RuntimeError('Encoded clip mismatch: '+name)
 print(f'COMPLETE: girl-{name}.mp4 / {count} frames / {count/30:.3f} seconds',flush=True)
 return name
start=time.monotonic();print('Rendering Blender opening, return, ending. Exact total: 1235 frames.',flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=a.workers) as pool:
 futures=[pool.submit(render,s) for s in CLIPS]
 for f in concurrent.futures.as_completed(futures):f.result()
print(f'All Blender clips complete in {(time.monotonic()-start)/60:.1f} minutes.',flush=True)
