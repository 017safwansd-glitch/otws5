#!/usr/bin/env python3
from pathlib import Path
import zipfile
root=Path(__file__).resolve().parents[1];out=root/'out'/'recool-project.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for file in sorted(root.rglob('*')):
  rel=file.relative_to(root)
  if any(p in {'.git','node_modules','out','.remotion'} for p in rel.parts):continue
  if file.suffix=='.blend1' or rel.as_posix()=='src/data/assets.generated.json':continue
  if file.is_file():z.write(file,'recool-project/'+str(rel))
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 for file in ['public/assets/recool-logo.png','public/assets/recool-60ml.png','public/assets/recool-150ml.png','public/assets/girl-opening.mp4','public/assets/girl-return.mp4','public/assets/girl-ending.mp4','blender/girl-opening.blend','blender/girl-return.blend','blender/girl-ending.blend']:
  assert 'recool-project/'+file in z.namelist(),file
 print('Archive verified:',len(z.namelist()),'files,',round(out.stat().st_size/1024/1024,2),'MiB')
