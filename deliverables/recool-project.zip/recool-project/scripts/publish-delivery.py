#!/usr/bin/env python3
"""Publish the user-authorized download artifacts, preserving the checkout and main branch."""
from pathlib import Path
import subprocess,os,tempfile,argparse
root=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--clips-only',action='store_true');a=p.parse_args();branch='recool-video-downloads'
def git(*args,env=None,input=None):
 r=subprocess.run(['git',*args],cwd=root,env=env,input=input,text=True,capture_output=True)
 if r.returncode:raise RuntimeError(r.stderr.strip())
 return r.stdout.strip()
git('fetch','origin',branch);parent=git('rev-parse','FETCH_HEAD')
files=[('public/assets/girl-opening.mp4','deliverables/girl-opening.mp4'),('public/assets/girl-return.mp4','deliverables/girl-return.mp4'),('public/assets/girl-ending.mp4','deliverables/girl-ending.mp4')]
if not a.clips_only:files += [('out/recool-pitch.mp4','deliverables/recool-pitch.mp4'),('out/recool-project.zip','deliverables/recool-project.zip')]
readme=Path('/tmp/recool-delivery-readme.md')
readme.write_text('''# Parachute ReCool downloads

- [Download the full MP4](./recool-pitch.mp4?raw=true)
- [Download the complete Remotion + Blender project ZIP](./recool-project.zip?raw=true)

## Three native Blender girl clips

| Clip | Duration | Download |
|---|---|---|
| Opening: doorway, street, fan, return outdoors | 20 seconds / 600 frames | [MP4](./girl-opening.mp4?raw=true) |
| Return outdoors | 6 seconds / 180 frames | [MP4](./girl-return.mp4?raw=true) |
| Ending: same doorway, continued afternoon | 15.167 seconds / 455 frames | [MP4](./girl-ending.mp4?raw=true) |

'''+('The three Blender clips are available now. The full MP4 and ZIP above still contain the earlier draft while the revised three-minute cut finishes rendering.\n' if a.clips_only else 'The full revised MP4 is 1920×1080, 30 fps, exactly 180 seconds / 5,400 frames. It uses the uploaded original bottle PNGs and the one combined logo. Missing presenters leave plain white space with no markers. The project ZIP includes all three Blender clips, their editable .blend files, the Remotion source, and the supplied merged product video. Narration/music have not been supplied; the current cut is silent with editable script captions.\n'))
files.append((str(readme),'deliverables/README.md'))
fd,index=tempfile.mkstemp(prefix='recool-upload-',suffix='.index',dir='/tmp');os.close(fd);os.unlink(index)
env=os.environ.copy();env['GIT_INDEX_FILE']=index
try:
 git('read-tree',parent,env=env)
 for source,dest in files:
  oid=git('hash-object','-w',source);git('update-index','--add','--cacheinfo',f'100644,{oid},{dest}',env=env)
 tree=git('write-tree',env=env)
 message='Add native Blender story clips' if a.clips_only else 'Update ReCool video with Blender story clips and official artwork'
 commit=git('-c','user.name=Codex','-c','user.email=codex@users.noreply.github.com','commit-tree',tree,'-p',parent,input=message+'\n')
 old=git('rev-parse',f'refs/heads/{branch}');git('update-ref',f'refs/heads/{branch}',commit,old)
 print(git('push','origin',f'refs/heads/{branch}:refs/heads/{branch}'))
 remote=git('ls-remote','origin',f'refs/heads/{branch}').split()[0]
 if remote!=commit:raise RuntimeError('Remote verification mismatch')
 print('Published and verified:',commit)
 (root/'out'/('clips-published-sha.txt' if a.clips_only else 'revision-published-sha.txt')).write_text(commit+'\n')
finally:Path(index).unlink(missing_ok=True)
