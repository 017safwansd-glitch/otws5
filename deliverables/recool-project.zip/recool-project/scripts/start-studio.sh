#!/usr/bin/env bash
set -euo pipefail
cd /workspace/otws5
npm run assets
exec ./node_modules/.bin/remotion studio src/index.ts --port=3000 --no-open
