import React from 'react';
import {Composition,registerRoot,staticFile} from 'remotion';
import {Video} from '@remotion/media';
const SourceHero:React.FC=()=> <Video src={staticFile('assets/recool-merged.mp4')} trimBefore={708} trimAfter={765} playbackRate={1} muted objectFit="cover" style={{width:1920,height:1080}}/>;
const Root:React.FC=()=> <Composition id="SourceHeroTimingQA" component={SourceHero} width={1920} height={1080} fps={30} durationInFrames={57}/>;
registerRoot(Root);
