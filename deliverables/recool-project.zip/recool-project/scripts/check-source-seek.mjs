import {bundle} from '@remotion/bundler';
import {getCompositions,renderStill} from '@remotion/renderer';
const serveUrl=await bundle({entryPoint:'scripts/media-qa.tsx'});
const browserExecutable='/usr/bin/chromium';
const [composition]=await getCompositions(serveUrl,{browserExecutable});
await renderStill({serveUrl,composition,browserExecutable,frame:0,output:'out/source-seek-qa.png'});
console.log('Rendered final source segment frame zero with trimBefore=708 at composition fps=30.');
