import {bundle} from '@remotion/bundler';
import {getCompositions,renderStill,openBrowser} from '@remotion/renderer';
import {mkdirSync,writeFileSync} from 'node:fs';
const serveUrl=await bundle({entryPoint:'src/index.ts'});
const browser=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium'});
try {
 const compositions=await getCompositions(serveUrl,{puppeteerInstance:browser,browserExecutable:'/usr/bin/chromium'});
 writeFileSync('out/compositions.json',JSON.stringify(compositions,null,2));
 const main=compositions.find(c=>c.id==='ReCoolPitch');
 if(main.durationInFrames!==5400||main.width!==1920||main.height!==1080||main.fps!==30)throw new Error('Composition specifications failed');
 mkdirSync('out/review',{recursive:true});
 const checks=[['opening',320],['humidity',800],['climate',1050],['conditions',1620],['revelation',2470],['product-video',2980],['science-contact',3480],['science-release',3580],['science-trpm8',3780],['hero',3930],['skus',4175],['market',4430],['financials',4770],['ending',5190],['endcard',5310]];
 for(const [name,frame] of checks){await renderStill({serveUrl,composition:main,frame,output:`out/review/${name}.png`,puppeteerInstance:browser,browserExecutable:'/usr/bin/chromium'});console.log(`Rendered ${name} at frame ${frame}`);}
 for(const c of compositions.filter(c=>/^Scene\d$/.test(c.id))){await renderStill({serveUrl,composition:c,frame:0,output:`out/review/${c.id}-start.png`,puppeteerInstance:browser,browserExecutable:'/usr/bin/chromium'});console.log(`Scene preview verified: ${c.id}`);}
} finally {await browser.close({silent:true});}
