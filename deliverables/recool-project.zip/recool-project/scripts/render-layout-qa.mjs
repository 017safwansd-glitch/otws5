import {bundle} from '@remotion/bundler';
import {getCompositions,renderStill,openBrowser} from '@remotion/renderer';
import {mkdirSync} from 'node:fs';
const serveUrl=await bundle({entryPoint:'src/index.ts'});
const browserExecutable='/usr/bin/chromium';const browser=await openBrowser('chrome',{browserExecutable});
try {
 const main=(await getCompositions(serveUrl,{puppeteerInstance:browser,browserExecutable})).find(c=>c.id==='ReCoolPitch');
 mkdirSync('out/revision-qa',{recursive:true});
 for(const [name,frame] of [['clean-presenter-space',1050],['official-skus',4175],['official-hero',3930],['official-endcard',5310],['science-clean-text',3780]]){
  await renderStill({serveUrl,composition:main,frame,output:`out/revision-qa/${name}.png`,puppeteerInstance:browser,browserExecutable});
  console.log('Rendered revised layout:',name);
 }
} finally {await browser.close({silent:true});}
