import ts from 'typescript';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
const source=ts.createSourceFile('cues.ts',readFileSync('src/data/narration-cues.ts','utf8'),ts.ScriptTarget.Latest,true);
let cues;
function visit(node){if(ts.isVariableDeclaration(node)&&node.name.getText(source)==='narrationCues')cues=JSON.parse(node.initializer.getText(source));ts.forEachChild(node,visit);}
visit(source);
const columns=['id','sceneId','spokenPhrase','startFrame','endFrame','animationId','emphasis','notes'];
const escape=v=>'"'+String(v).replaceAll('"','""')+'"';
mkdirSync('docs',{recursive:true});
writeFileSync('docs/narration-cues.csv',[columns.join(','),...cues.map(c=>columns.map(k=>escape(c[k])).join(','))].join('\n')+'\n');
console.log(`Exported ${cues.length} cues for recording review. Edit src/data/narration-cues.ts to change the film.`);
