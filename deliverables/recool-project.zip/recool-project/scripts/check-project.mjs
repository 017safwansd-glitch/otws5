import assert from 'node:assert/strict';
import {readFileSync,existsSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import ts from 'typescript';
// Load the actual TypeScript data modules, including their dependencies, rather than duplicating timeline constants.
const loaded = new Map();
function dataModule(name) {
 if(loaded.has(name)) return loaded.get(name);
 const source=readFileSync(`src/data/${name}.ts`,'utf8');
 const code=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 const module={exports:{}};
 new Function('require','module','exports',code)(path=>dataModule(path.replace('./','')),module,module.exports);
 loaded.set(name,module.exports);return module.exports;
}
const {SCENES,FPS,DURATION,VIDEO_SEGMENTS}=dataModule('timeline');
const {narrationCues}=dataModule('narration-cues');
const {products}=dataModule('product');
const {financials}=dataModule('financials');
assert.equal(FPS,30);assert.equal(DURATION,5400);
let end=0;
for(const s of SCENES){assert.equal(s.from,end,`Gap or overlap at scene ${s.id}`);assert.ok(s.duration>0);end+=s.duration;}
assert.equal(end,DURATION);
assert.equal(SCENES.filter(s=>s.presenter).reduce((n,s)=>n+s.duration,0),2160);
assert.equal(SCENES.filter(s=>!s.presenter).reduce((n,s)=>n+s.duration,0),3240);
assert.equal(SCENES.find(s=>s.id===6).duration,525);
for(const s of SCENES){const cues=narrationCues.filter(c=>c.sceneId===s.id);assert.ok(cues.length);for(const c of cues){assert.ok(c.startFrame>=s.from&&c.endFrame<=s.from+s.duration&&c.endFrame>c.startFrame,`Cue out of bounds: ${c.id}`);}}
assert.equal(new Set(narrationCues.map(c=>c.id)).size,narrationCues.length);
assert.deepEqual(products.map(p=>[p.size,p.price]),[[60,175],[150,275]]);
assert.deepEqual([financials.tam,financials.netSales,financials.ebitda],[1189,17.22,2.58]);
const endcard=narrationCues.find(c=>c.id==='s9-brand').startFrame;assert.ok(DURATION-endcard>=90,'End card must hold for at least 3 seconds');
assert.deepEqual(VIDEO_SEGMENTS.map(v=>[v.from,v.duration,v.trimBefore]),[[2670,708,0],[3903,57,708]]);
const manifest=JSON.parse(readFileSync('src/data/assets.generated.json','utf8'));
assert.equal(manifest.assets.merged,'assets/recool-merged.mp4','Required source video is missing');
const probe=spawnSync('ffprobe',['-v','error','-show_entries','format=duration:stream=codec_type,width,height,r_frame_rate,nb_frames,duration','-of','json','public/assets/recool-merged.mp4'],{encoding:'utf8'});
assert.equal(probe.status,0,probe.stderr);const meta=JSON.parse(probe.stdout);const video=meta.streams.find(s=>s.codec_type==='video');
assert.ok(Number(video.duration)>=25.5,'Decoded video track is shorter than 25.5 seconds');
assert.deepEqual([video.width,video.height],[1920,1080]);
console.log(`PASS: 9 contiguous scenes; 5400 frames / 180 s; presenter slots 72 s; fullscreen 108 s.`);
console.log(`PASS: ${narrationCues.length} bounded cues; accurate SKUs/forecasts; science 525 frames; end card ${(DURATION-endcard)/30} s.`);
console.log(`PASS: single MP4, ${video.r_frame_rate} fps, ${video.duration} s video track; source trims 0–23.6 and 23.6–25.5 s.`);
for(const file of ['logo','goPack','homePack','presenter1','presenter2','presenter3','narration'])if(!manifest.assets[file]) console.log(`PENDING ASSET: ${file} (placeholder/review draft)`);
